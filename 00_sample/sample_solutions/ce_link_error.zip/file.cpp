#include "file.h"

Foo::Foo(int value) : value_(value) {}

void Foo::IncValue() {
  ++value_;
}
