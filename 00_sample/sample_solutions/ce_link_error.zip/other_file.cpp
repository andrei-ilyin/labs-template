int SomeFunc(int x) {
  return x * 42;
}

#ifndef IGNORE_SOLUTION_MAIN
int main() {
  return 0;
}
#endif  // IGNORE_SOLUTION_MAIN
